package me.storm.ninegag.view;

/**
 * Created by storm on 14-5-6.
 */
public interface OnLoadNextListener {
    public void onLoadNext();
}
